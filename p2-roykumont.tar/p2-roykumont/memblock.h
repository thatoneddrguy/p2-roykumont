// memblock defintion
struct memblock
{
    int processNum;  // processNum == 0 means memblock is available
    int pageNum;
};
